import { BrowserRouter, Routes, Route, Link, NavLink } from "react-router-dom";
import { useState } from "react";

const Home = () => {
  return <h1>Home</h1>;
};

const Detail = () => {
  return <h1>Detail</h1>;
};

function App() {
  const [beverages, setBeverages] = useState([
    {
      id: 1,
      title: "여수 윤슬 헤이즐넛 콜드브루",
      desc: "윤슬을 형상화한 헤이즐넛 콜드브루",
    },
    {
      id: 2,
      title: "아이스 오렌지 판타지 유스베리 티",
      desc: "상큼한 오렌지와 유스베리, 얼그레이 티의 조화",
    },
  ]);

  return (
    <BrowserRouter>
      <ul>
        <li>
          {/* 새로고침 없이 a태그 기능을 해주는 요소 */}
          <Link to="/">Home</Link>
        </li>
        <li>
          {/* Link와 같은 기능이지만 클래스 속성에 active가 붙는다 */}
          <NavLink to="/detail">Detail</NavLink>
        </li>
      </ul>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/detail" element={<Detail />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
