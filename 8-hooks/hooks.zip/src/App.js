// import Counter from "./components/Counter";
import Converter from "./components/Converter";

const App = () => {
  // 공통적인 기능을 Components로 만들어서 편리하게 사용가능
  return <Converter />; // Counter Components를 통째로 넘긴다.
};

export default App;
